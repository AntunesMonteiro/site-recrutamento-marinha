
// Slider de Testemunhos (mostrar um de cada vez)
const testemunhos = document.querySelectorAll('.testemunho');
const btnEsq = document.getElementById('btn-esquerda');
const btnDir = document.getElementById('btn-direita');
let atual = 0;

function mostrarTestemunho(index) {
  testemunhos.forEach((el, i) => {
    el.classList.toggle('ativo', i === index);
  });
}

btnDir?.addEventListener('click', () => {
  atual = (atual + 1) % testemunhos.length;
  mostrarTestemunho(atual);
});

btnEsq?.addEventListener('click', () => {
  atual = (atual - 1 + testemunhos.length) % testemunhos.length;
  mostrarTestemunho(atual);
});
